<aside class="aside">
    <div class="aside-wrap">
        <div class="side-widget">
            <?php get_template_part( 'templates/components/category-products-list' ); ?>
        </div>
        <div class="side-widget">
            <?php get_template_part( 'templates/components/hot-products' ); ?>
        </div>
        <div class="side-widget">
            <?php get_template_part( 'templates/components/tags-assembly' ); ?>
        </div>
    </div>
</aside>
